# src/main/resources/templates

Thymeleaf 등에서 사용하는 템플릿 파일을 두는 폴더
