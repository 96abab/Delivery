# src/main/resources/static

웹 정적 자원(HTML, CSS, JavaScript, Image 파일 등)을 두는 폴더
